package com.example.exemploservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnIniciar, btnParar;
    private Intent it;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnIniciar = findViewById(R.id.botaoGo);
        btnParar = findViewById(R.id.botaoSt);
        it = new Intent(this, MyService.class);
        btnIniciar.setOnClickListener(v -> {
            start();
        });
        btnParar.setOnClickListener(v -> {
            stop();
        });
    }

    private void stop() {

    }

    private void start() {
        Log.e("Thread1", Thread.currentThread().getName());
        startService(it);
    }
}