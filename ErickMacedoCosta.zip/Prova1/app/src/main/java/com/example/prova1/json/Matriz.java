package com.example.prova1.json;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Matriz {
    @SerializedName("vetores")
    @Expose
    private List<List<Integer>> vetores;

    public List<List<Integer>> getVetores() {
        return vetores;
    }

    public void setVetores(List<List<Integer>> vetores) {
        this.vetores = vetores;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Matriz.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("vetores");
        sb.append('=');
        sb.append(((this.vetores == null)?"<null>":this.vetores));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}