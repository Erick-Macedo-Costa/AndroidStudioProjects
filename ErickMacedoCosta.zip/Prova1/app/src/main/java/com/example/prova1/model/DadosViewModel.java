package com.example.prova1.model;


import android.os.AsyncTask;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.prova1.R;
import com.example.prova1.json.Auxilia;
import com.example.prova1.json.Conexao;
import com.example.prova1.json.Matriz;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class DadosViewModel extends ViewModel {
    private final MutableLiveData<String> mText;
    private final MutableLiveData<String> mText2;
    private final MutableLiveData<String> mText3;
    private static final MutableLiveData<String> mText4 = new MutableLiveData<>();
    private final MutableLiveData <Integer> mImage;
    private final MutableLiveData <Integer> mImage2;
    private final MutableLiveData <Integer> mImage3;
    private final String URL= "https://my-json-server.typicode.com/Erick-Macedo-Costa/ExemplosPDM2/db";
    private StringBuilder builder = null;
    private Matriz dadosBaixados = null;
    private static Set<Integer> numerosGerados = new HashSet<>();
    private static int tamanhoNome;
    public Matriz getMatriz() {
        return dadosBaixados;
    }
    public List<Integer> listaMatriz1;
    public List<Integer> listaMatriz2;
    public List<Integer> listaMatriz3;

    public DadosViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("");
        mText2 = new MutableLiveData<>();
        mText2.setValue("");
        mText3 = new MutableLiveData<>();
        mText3.setValue("");
        mText4.setValue("");
        mImage = new MutableLiveData<>();
        mImage.setValue(R.drawable.recibo);
        mImage2 = new MutableLiveData<>();
        mImage2.setValue(R.drawable.combinar);
        mImage3 = new MutableLiveData<>();
        mImage3.setValue(R.drawable.sortear);
        new obterDados().execute();
        gerarNumerosAleatorios();// AQUI QUE GERO OS NUMEROS NA SEGUNDA TELA
        //System.out.println("\n\n\n"+numerosGerados + "2 lugar de gerar numeros gerados" );
    }
    private class obterDados extends AsyncTask<Void, Void, Void> { //AQUI LEIO O JSON

        @Override
        protected Void doInBackground(Void... voids) {
            Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHTTP(URL);
            Auxilia auxilia = new Auxilia();
            String textoJSON = auxilia.converter(inputStream);
            //Log.i("JSON", "doInBackground: "+textoJSON);
            Gson gson = new Gson();
            builder = new StringBuilder();

            if(textoJSON != null){
                Type type = new TypeToken<Matriz>(){}.getType();
                dadosBaixados = gson.fromJson(textoJSON,type);
                for (int i = 0; i < dadosBaixados.getVetores().size(); i++) {
                    builder.append(dadosBaixados.getVetores().get(i).toString())
                            .append("\n");
                }
            }else{
                builder.append("Não foi possível obter os dados");
            }
            return null;
        }//doInBackground

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            verificarNumeros(); // AQUI QUE VERIFICAR OS NUMEROS NA SEGUNDA TELA
            //System.out.println("\n\n\n"+numerosGerados + "3 lugar de gerar numeros gerados" );
            getmText().setValue(builder.toString());
            //System.out.println("\n\n\n >>>> " + getMatriz()+ " <<<< esse?" );
            listaMatriz1 = new ArrayList<>(getMatriz().getVetores().get(0));
            listaMatriz2 = new ArrayList<>(getMatriz().getVetores().get(1));
            listaMatriz3 = new ArrayList<>(gerarNumerosAleatorios());
        }



    }//obterDados

    public List<Integer> gerarNumerosAleatorios() {// AQUI QUE GERO OS NUMEROS NA SEGUNDA TELA
        Random random = new Random();
        while (numerosGerados.size() < 10) {
            int numero = random.nextInt(20) + 1;
            numerosGerados.add(numero);
        }
        mText2.setValue(numerosGerados.toString());
        //System.out.println("\n\n\n"+numerosGerados + "1 lugar de gerar numeros gerados" );
        return new ArrayList<>(numerosGerados);
    }

    private void verificarNumeros() {// AQUI QUE VERIFICAR OS NUMEROS NA SEGUNDA TELA
        if (dadosBaixados != null && !dadosBaixados.getVetores().isEmpty()) {
            List<List<Integer>> vetores = dadosBaixados.getVetores();
//            System.out.println("\n\n\n"+vetores.get(0));
//            System.out.println(vetores.get(1));
//            System.out.println(numerosGerados);
            StringBuilder resultado = new StringBuilder();

            for (int i = 0; i < vetores.size(); i++) {
                List<Integer> vetor = vetores.get(i);
                int numerosComuns = 0;

                for (int numero : vetor) {
                    if (numerosGerados.contains(numero)) {
                        numerosComuns++;
                    }
                }

                resultado.append("Bilhete ")
                        .append(i + 1).append(": ")
                        .append(numerosComuns)
                        .append(" acertos")
                        .append("\n");
            }
            mText3.setValue(resultado.toString());
        } else {
            mText3.setValue("Nenhum dado encontrado.");
        }
    }

    public static void getNome(String nome){
        //System.out.println("\n\n\n"+nome.length());
        tamanhoNome = nome.length();
        rertornaNumeros();
    }

    public static int rertornaNumeros(){
        int soma = 0;
        List<Integer> numerosEmbaralhados = new ArrayList<>(numerosGerados);
      for (int i = 0; i <tamanhoNome; i++) {
          Collections.shuffle(numerosEmbaralhados);
            soma += numerosEmbaralhados.get(0);
          //System.out.println("\n\n\n numeros gerados"+numerosEmbaralhados.get(0));
      }
        //System.out.println("\n\n\n"+soma + " soma");
      mText4.setValue(String.valueOf(soma));
        return soma;
    }



    public MutableLiveData<String> getmText() { // AQUI QUE LEIO OS NUMEROS JSON PRIMEIRA TELA
        return mText;
    }
    public MutableLiveData<String> getmText2() { // AQUI QUE PASSO OS NUMEROS GERADOS SEGUNDA TELA
        return mText2;
    }
    public MutableLiveData<String> getmText3() { // AQUI QUE PASSO A VERIFICAÇÃO SEGUNDA TELA
        return mText3;
    }
    public MutableLiveData<String> getmText4() { // AQUI QUE PASSO A SOMA DOS NUMEROS
        return mText4;
    }
    public MutableLiveData<Integer> getmImage() {// AQUI QUE PASSO A IMAGEM PRIMEIRA TELA
        return mImage;
    } public MutableLiveData<Integer> getmImage2() {// AQUI QUE PASSO A IMAGEM QUARTA TELA
        return mImage2;
    }
    public MutableLiveData<Integer> getmImage3() {// AQUI QUE PASSO A IMAGEM TERCEIRA TELA
    return mImage3;
}

}
