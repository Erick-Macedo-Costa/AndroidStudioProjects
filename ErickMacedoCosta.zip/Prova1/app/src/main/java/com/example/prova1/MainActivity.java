package com.example.prova1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.prova1.databinding.ActivityMainBinding;
import com.example.prova1.fragment.FragmentCapturar;
import com.google.android.material.navigation.NavigationView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private static final int CODIGO_SOLICITACAO = 1;
    private static final String PERMISSOES = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        binding.appBarMain.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(it);
            }
        });

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;

        appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_iniciar, R.id.nav_sortear, R.id.nav_combinar, R.id.nav_capturar)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.armazenar){
            solicitarPermissao();
           // Toast.makeText(this, "armazenar", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
    private void salvarMedia() {
        File diretorioDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File arquivo = new File(diretorioDownloads, "dados.txt");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(arquivo);
            String dados = "Item A: "+FragmentCapturar.textoA() + "\nItem D: " + FragmentCapturar.textoD();
            fileOutputStream.write(dados.getBytes());
            fileOutputStream.close();
            Toast.makeText(this, "Dados salvos no diretório de downloads", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao salvar os dados", Toast.LENGTH_SHORT).show();
        }

    }
    private void solicitarPermissao() {
        int temPermissao = ContextCompat.checkSelfPermission(this, PERMISSOES);
        if (temPermissao != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{PERMISSOES}, CODIGO_SOLICITACAO);
        } else {
            salvarMedia();
            Intent it = new Intent(MainActivity.this, LottieActivity.class);
            startActivity(it);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode!= CODIGO_SOLICITACAO){
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            return;
        }
        if(grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                salvarMedia();
                Intent it = new Intent(MainActivity.this, LottieActivity.class);
                startActivity(it);
            } else {
                if(ActivityCompat.shouldShowRequestPermissionRationale(this,PERMISSOES)){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Atenção")
                            .setMessage("É necessário a permissão para salvar a media")
                            .setCancelable(false)
                            .setPositiveButton("Sim", (dialog, which) -> {
                                ActivityCompat.requestPermissions(this, new String[]{PERMISSOES}, CODIGO_SOLICITACAO);
                            })
                            .setNegativeButton("Não", (dialog, which) -> {
                                Toast.makeText(this, "e necessario para funcionar...ADEUS!", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else {
                    finish();
                }
            }
        }
    }
}