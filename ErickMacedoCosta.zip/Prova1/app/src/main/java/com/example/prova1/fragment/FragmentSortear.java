package com.example.prova1.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.prova1.databinding.FragmentSortearBinding;
import com.example.prova1.model.DadosViewModel;

public class FragmentSortear extends Fragment {
    private FragmentSortearBinding binding;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        binding = FragmentSortearBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        TextView json = binding.json;
        TextView numeros = binding.numeros;
        TextView verificacao = binding.verificar;
        ImageView imageView = binding.imageSortear;
        DadosViewModel dadosViewModel = new ViewModelProvider(this).get(DadosViewModel.class);
        dadosViewModel.getmText().observe(getViewLifecycleOwner(), json::setText);
        dadosViewModel.getmText2().observe(getViewLifecycleOwner(), numeros::setText);
        dadosViewModel.getmText3().observe(getViewLifecycleOwner(), verificacao::setText);
        dadosViewModel.getmImage3().observe(getViewLifecycleOwner(), imageView::setImageResource);
        //System.out.println("\n\n\n"+dadosViewModel.getmText2() + "sortear numeros gerados" );
        return root;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

