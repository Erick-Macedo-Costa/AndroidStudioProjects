package com.example.prova1.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.prova1.databinding.FragmentCapturarBinding;
import com.example.prova1.model.DadosViewModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FragmentCapturar extends Fragment {
    private FragmentCapturarBinding binding;
    private DadosViewModel dadosViewModel;
    private static List<Integer> listaJuntarMatriz;
    private static List<Integer> listaVerDecrescente;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        binding = FragmentCapturarBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        TextView textView = binding.textView;
        Button juntar = binding.juntar;
        Button maior = binding.maior;
        Button media = binding.media;
        Button descrecente = binding.descrecente;
        dadosViewModel = new ViewModelProvider(requireActivity()).get(DadosViewModel.class);

        juntar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Juntar", Toast.LENGTH_SHORT).show();
//                System.out.println(dadosViewModel.listaMatriz1);
//                System.out.println(dadosViewModel.listaMatriz2);
//                System.out.println(dadosViewModel.listaMatriz3);
//                System.out.println(juntarMatriz() + "MATRIZ ");
                listaJuntarMatriz = juntarMatriz();
                textView.setText("Lista: " + listaJuntarMatriz.toString());
            }
        });
        maior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Maior", Toast.LENGTH_SHORT).show();
                List<Integer> verMaior = juntarMatriz();
                    int maiorNumero = verMaior.get(0);
                    for (int i = 1; i < verMaior.size(); i++) {
                        int numeroAtual = verMaior.get(i);

                        if (numeroAtual > maiorNumero) {
                            maiorNumero = numeroAtual;
                        }
                    }
                    textView.setText("Maior: " + maiorNumero);
                }
        });
        media.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Média", Toast.LENGTH_SHORT).show();
                List<Integer> verMedia = juntarMatriz();
                    int soma = 0;
                    for (int i = 0; i < verMedia.size(); i++) {
                            soma += verMedia.get(i);
                    }
                    double media = (double) soma / verMedia.size();
                    textView.setText("Média: " + media);
                }
        });
        descrecente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getContext(), "Decrescente", Toast.LENGTH_SHORT).show();
                listaVerDecrescente = juntarMatriz();
                Collections.sort(listaVerDecrescente, Collections.reverseOrder());
                textView.setText("Decrescente: " + listaVerDecrescente.toString());
                }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    public List<Integer> juntarMatriz() {
        List<Integer> listasMatriz = new ArrayList<>(dadosViewModel.listaMatriz1);
        List<Integer> listaMatriz2 = dadosViewModel.listaMatriz2;
        List<Integer> listaMatriz3 = dadosViewModel.listaMatriz3;
        listasMatriz.addAll(listaMatriz2);
        listasMatriz.addAll(listaMatriz3);
        return listasMatriz;
    }
    public static String textoA() {
        if (listaJuntarMatriz != null) {
            return listaJuntarMatriz.toString();
        }
        return "Lista Juntar vazia";
    }

    public static String textoD() {
        if (listaVerDecrescente != null) {
            Collections.sort(listaVerDecrescente, Collections.reverseOrder());
            return listaVerDecrescente.toString();
        }
        return "Lista Decrescente vazia";
    }

}

