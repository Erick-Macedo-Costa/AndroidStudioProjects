package com.example.prova1.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.prova1.databinding.FragmentIniciarBinding;
import com.example.prova1.model.DadosViewModel;

public class FragmentIniciar extends Fragment {
    private FragmentIniciarBinding binding;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentIniciarBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        TextView textView = binding.textPrimeiro;
        ImageView imageView = binding.imagePrimeiro;
        DadosViewModel dadosViewModel = new ViewModelProvider(this).get(DadosViewModel.class);
        dadosViewModel.getmText().observe(getViewLifecycleOwner(), textView::setText);
        dadosViewModel.getmImage().observe(getViewLifecycleOwner(), imageView::setImageResource);
        return root;

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}