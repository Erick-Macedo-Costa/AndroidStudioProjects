package com.example.appmanager.api.entity;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DadosMatriz {
    @SerializedName("matriz")
    @Expose
    private List<List<Integer>> matriz;

    public DadosMatriz(List<List<Integer>> matriz) {
        this.matriz = matriz;
    }

    public List<List<Integer>> getMatriz() {
        return matriz;
    }

    public void setMatriz(List<List<Integer>> matriz) {
        this.matriz = matriz;
    }
}
