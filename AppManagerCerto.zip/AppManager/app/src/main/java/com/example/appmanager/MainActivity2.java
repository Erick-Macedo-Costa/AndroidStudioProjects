package com.example.appmanager;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import com.example.appmanager.api.Auxilia;
import com.example.appmanager.api.Conexao;
import com.example.appmanager.api.entity.DadosMatriz;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


import java.io.InputStream;
import java.lang.reflect.Type;

public class MainActivity2 extends AppCompatActivity {
    private TextView textView;
    private StringBuilder builder = null;
    private DadosMatriz dadosMatriz;
    private final String URL= "https://my-json-server.typicode.com/viniiciusmoura/provapdm/db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        new obterDados().execute();
        textView = findViewById(R.id.dadosJson);

    }
    private class obterDados extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids)
        {
            Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHTTP(URL);
            Auxilia auxilia = new Auxilia();
            String textoJSON = auxilia.converter(inputStream);
            Gson gson = new Gson();
            builder = new StringBuilder();
            if(textoJSON != null){
            Type type = new TypeToken<DadosMatriz>(){}.getType();
            dadosMatriz = gson.fromJson(textoJSON,type);
            for (int i = 0; i < dadosMatriz.getMatriz().size(); i++) {
                builder.append(dadosMatriz.getMatriz().get(i).toString())
                        .append("\n");
            }
        }else{
            builder.append("Erro ao obter dados");
        }
            return null;
    }//doInBackground

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();
    }
    @Override
    protected void onPostExecute(Void unused)
    {
        super.onPostExecute(unused);
        textView.setText(builder.toString());
    }
}
}