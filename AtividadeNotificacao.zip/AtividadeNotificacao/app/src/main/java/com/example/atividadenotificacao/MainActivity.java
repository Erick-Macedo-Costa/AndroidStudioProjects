package com.example.atividadenotificacao;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Jogo> jogos = new ArrayList<>();
    private static final String CANAL_ID = "2";
    private static final int NOTIFICACAO_ID = 1;
    private Notification builder;
    private NotificationManagerCompat manager;
    private Button button;
    private static final String PERMISSAO = Manifest.permission.POST_NOTIFICATIONS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.botao);
        button.setOnClickListener(v -> {
            adicionarJogos();
            gerar(); 
        });
    }

    @SuppressLint("MissingPermission")
    private void gerar() {
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("media", dados());
        System.out.println("\n\n\n aaaaaaaa "+dados());
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,PendingIntent.FLAG_UPDATE_CURRENT);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.recibo);
        builder = new NotificationCompat.Builder(this, CANAL_ID)
                .setSmallIcon(R.drawable.recibo)
                .setContentTitle("Notificação")
                .setContentText("Jogos Preechidos")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pi)
                .setLargeIcon(bitmap)
                .setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bitmap)).build();
        manager = NotificationManagerCompat.from(this);
        int temPermissao = ContextCompat.checkSelfPermission(this, PERMISSAO);
        if (temPermissao == PackageManager.PERMISSION_GRANTED) {
            manager.notify(NOTIFICACAO_ID, builder);
        }
    }
    private void adicionarJogos() {
        jogos.add(new Jogo("Jogo 1", 250, "Ação", "PS4"));
        jogos.add(new Jogo("Jogo 2", 105, "Aventura", "Xbox One"));
        jogos.add(new Jogo("Jogo 3", 80, "Esporte", "PC"));
    }
    private double media() {
        double soma = 0;
        for (Jogo jogo : jogos) {
            soma += jogo.getPreco();
        }
        double media = soma / jogos.size();
        System.out.println("\n\n\n aaaaaaaa "+media);
        return media;
    }

    private String dados() {
        return "Media: " + media();
    }
}