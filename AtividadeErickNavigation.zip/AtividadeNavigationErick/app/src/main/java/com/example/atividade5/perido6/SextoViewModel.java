package com.example.atividade5.perido6;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.atividade5.R;

import java.util.HashMap;
import java.util.Map;

public class SextoViewModel extends ViewModel {
    private static Map<String, Integer> disciplinaImageMap = null;

    public SextoViewModel() {
        disciplinaImageMap = new HashMap<>();
        disciplinaImageMap.put("Novas Tecnologias em Desenvolvimento para Web", R.drawable.feliz);
        disciplinaImageMap.put("Gerência de Configuração", R.drawable.feliz);
        disciplinaImageMap.put("Padrões de Projeto", R.drawable.confuso);
        disciplinaImageMap.put("Programação para Dispositivos Móveis II", R.drawable.confuso);
    }

    public static Map<String, Integer> getDisciplinaImageMap() {
        return disciplinaImageMap;
    }
}