package com.example.atividade5.perido4;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.atividade5.R;

import java.util.HashMap;
import java.util.Map;

public class QuartoViewModel extends ViewModel {
    private static Map<String, Integer> disciplinaImageMap = null;
    public QuartoViewModel() {
        disciplinaImageMap = new HashMap<>();
        disciplinaImageMap.put("Sistemas Distribuídos e SOA", R.drawable.confuso);
        disciplinaImageMap.put("Projeto de Sistemas", R.drawable.feliz);
        disciplinaImageMap.put("Testes de Software", R.drawable.feliz);
        disciplinaImageMap.put("Projeto de Interface Web", R.drawable.feliz);
        disciplinaImageMap.put("Programação para Web II", R.drawable.triste);
        disciplinaImageMap.put("Eletiva", R.drawable.feliz);
    }

    public static Map<String, Integer> getDisciplinaImageMap() {
        return disciplinaImageMap;
    }
}