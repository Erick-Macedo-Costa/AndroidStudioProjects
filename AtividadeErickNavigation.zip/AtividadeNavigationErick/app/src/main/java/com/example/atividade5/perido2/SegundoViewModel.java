package com.example.atividade5.perido2;

import static android.provider.Settings.System.getString;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.atividade5.R;

import java.util.HashMap;
import java.util.Map;

public class SegundoViewModel extends ViewModel {
    private static Map<String, Integer> disciplinaImageMap = null;
    public SegundoViewModel() {
        disciplinaImageMap = new HashMap<>();
        disciplinaImageMap.put("Fundamentos e Projeto de Banco de Dados", R.drawable.confuso);
        disciplinaImageMap.put("Análise de Sistemas", R.drawable.feliz);
        disciplinaImageMap.put("Introdução à Programação", R.drawable.feliz);
        disciplinaImageMap.put("Programação Orientada a Objetos", R.drawable.triste);
        disciplinaImageMap.put("Introdução à Lógica", R.drawable.triste);
        disciplinaImageMap.put("Programação Básica para Web", R.drawable.feliz);
    }

    public static Map<String, Integer> getDisciplinaImageMap() {
        return disciplinaImageMap;
    }
}

