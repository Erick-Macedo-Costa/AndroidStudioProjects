package com.example.atividade5.perido1;

import static android.provider.Settings.System.getString;

import androidx.lifecycle.ViewModel;

import com.example.atividade5.R;

import java.util.HashMap;
import java.util.Map;

public class PrimeiroViewModel extends ViewModel {
    private static Map<String, Integer> disciplinaImageMap = null;

    public PrimeiroViewModel() {
        disciplinaImageMap = new HashMap<>();
        disciplinaImageMap.put("Fundamentos de Redes de Computadores", R.drawable.feliz);
        disciplinaImageMap.put("Tendências Tecnológicas para o Mercado de TI", R.drawable.feliz);
        disciplinaImageMap.put("Introdução a Computação", R.drawable.feliz);
        disciplinaImageMap.put("Informática Instrumental", R.drawable.feliz);
        disciplinaImageMap.put("Introdução à Lógica", R.drawable.confuso);
        disciplinaImageMap.put("Inglês Técnico", R.drawable.feliz);
    }

    public static Map<String, Integer> getDisciplinaImageMap() {
        return disciplinaImageMap;
    }
}

