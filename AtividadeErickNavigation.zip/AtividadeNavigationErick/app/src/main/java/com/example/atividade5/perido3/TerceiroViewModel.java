package com.example.atividade5.perido3;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.atividade5.R;

import java.util.HashMap;
import java.util.Map;

public class TerceiroViewModel extends ViewModel     {
    private static Map<String, Integer> disciplinaImageMap = null;

    public TerceiroViewModel() {
        disciplinaImageMap = new HashMap<>();
        disciplinaImageMap.put("Introdução à Conectividade", R.drawable.feliz);
        disciplinaImageMap.put("Gerenciamento de Dados para Web", R.drawable.feliz);
        disciplinaImageMap.put("Programação para Banco de Dados", R.drawable.feliz);
        disciplinaImageMap.put("Administração de Sistemas Proprietários", R.drawable.feliz);
        disciplinaImageMap.put("Programação para Web Designers", R.drawable.feliz);
        disciplinaImageMap.put("Programação para Web I", R.drawable.feliz);
    }

    public static Map<String, Integer> getDisciplinaImageMap() {
        return disciplinaImageMap;
    }
}


