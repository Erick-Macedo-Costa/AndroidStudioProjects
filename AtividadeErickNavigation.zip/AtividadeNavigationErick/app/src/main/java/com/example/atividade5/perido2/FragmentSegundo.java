package com.example.atividade5.perido2;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.atividade5.R;
import com.example.atividade5.databinding.FragmentPrimeiroBinding;
import com.example.atividade5.databinding.FragmentSegundoBinding;
import com.example.atividade5.perido1.PrimeiroViewModel;

import java.util.Map;

public class FragmentSegundo extends Fragment {
    private FragmentSegundoBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSegundoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        TableLayout tableLayout = binding.tableSegundo;
        SegundoViewModel segundoViewModel = new ViewModelProvider(this).get(SegundoViewModel.class);
        Map<String, Integer> disciplinaImageMap = segundoViewModel.getDisciplinaImageMap();

        for(Map.Entry<String, Integer> entry : disciplinaImageMap.entrySet()) {
            String text = entry.getKey();
            Integer img = entry.getValue();

            TableRow tableRow = new TableRow(requireContext());
            TextView textView = new TextView(requireContext());
            textView.setText(text);
            tableRow.addView(textView);

            ImageView imageView = new ImageView(requireContext());
            imageView.setImageResource(img);
            imageView.setLayoutParams(new TableRow.LayoutParams(48, 48));
            tableRow.addView(imageView);
            tableLayout.addView(tableRow);
        }

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}