package com.example.exemplohandler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView txt;
    private Button btn;
    private Handler handler;
    private Integer number6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = findViewById(R.id.textNumber);
        btn = findViewById(R.id.botaoClick);
        btn.setOnClickListener(v -> {
           click();
        });

    }
    private void click() {
        Log.i("Thread", Thread.currentThread().getName());
        Random random = new Random();
        handler = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            Log.i("Thread2", Thread.currentThread().getName());
            for (int i = 0; i < 10; i++) {
               number6 = random.nextInt(21) ;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                handler.post(() -> {
                    Log.i("Thread3", Thread.currentThread().getName());
                    txt.setText(String.valueOf(number6));
                });
            }
        }).start();
    }
}