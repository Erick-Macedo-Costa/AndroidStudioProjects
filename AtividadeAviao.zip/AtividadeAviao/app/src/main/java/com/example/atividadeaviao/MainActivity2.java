package com.example.atividadeaviao;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity2 extends AppCompatActivity {
    private TextView textView;
    private static final int CODIGO_SOLICITACAO = 1;
    private static final String PERMISSOES = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    private double media;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView = findViewById(R.id.textView);
        Intent intent = getIntent();
        media = intent.getIntExtra("media", 0);
        textView.setText(String.valueOf(media));
        solicitarPermissao();
    }

    private void salvarMedia() {
        File diretorioDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File arquivo = new File(diretorioDownloads, "meu_arquivo.txt");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(arquivo);
            fileOutputStream.write(String.valueOf(media).getBytes());
            fileOutputStream.close();
            Toast.makeText(this, "Dados salvos no diretório de downloads", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao salvar os dados", Toast.LENGTH_SHORT).show();
        }
    }
    private void solicitarPermissao() {
        int temPermissao = ContextCompat.checkSelfPermission(this, PERMISSOES);
        if (temPermissao != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{PERMISSOES}, CODIGO_SOLICITACAO);
        } else {
            salvarMedia();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode!= CODIGO_SOLICITACAO){
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            return;
        }
        if(grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                salvarMedia();
            } else {
                if(ActivityCompat.shouldShowRequestPermissionRationale(this,PERMISSOES)){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Atenção")
                            .setMessage("É necessário a permissão para salvar a media")
                            .setCancelable(false)
                            .setPositiveButton("Sim", (dialog, which) -> {
                                ActivityCompat.requestPermissions(this, new String[]{PERMISSOES}, CODIGO_SOLICITACAO);
                            })
                            .setNegativeButton("Não", (dialog, which) -> {
                                Toast.makeText(this, "e necessario para funcionar...ADEUS!", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else {
                    finish();
                }
            }
        }
    }
}