package com.example.atividadeaviao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Pessoa> pessoas = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pessoas.add(new Pessoa("Vinicus", 22));
        pessoas.add(new Pessoa("Flavio", 23));
        pessoas.add(new Pessoa("Erick", 21));
        MyBroadcastReceiver myBroadcastReceiver = new MyBroadcastReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(myBroadcastReceiver, intentFilter);
    }

    private int verificarMediaIdade() {
        int soma = 0;
        for(Pessoa pessoa : pessoas) {
            soma += pessoa.getIdade();
        }
        return soma / pessoas.size();
    }
    private class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (Settings.System.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0) {
                Toast.makeText(context, "MODO ON", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(context, MainActivity2.class);
                i.putExtra("media", verificarMediaIdade());
                startActivity(i);

            }
        }
    }
}