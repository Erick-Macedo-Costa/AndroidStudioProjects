package com.example.exemploservice2;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public MyService() {
        super();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("create","Service criado");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("thread2", Thread.currentThread().getName());
        for (int i = 0; i < 10; i++) {
            Log.i("laço", String.valueOf(i));
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("delete","Service encerrado");
    }
}
