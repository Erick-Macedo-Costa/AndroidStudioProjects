package com.example.exemploservice2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btnIniciar, btnParar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnIniciar = findViewById(R.id.botaoGO);
        btnParar = findViewById(R.id.botaoST);
        Intent intent = new Intent(this, MyService.class);
        btnIniciar.setOnClickListener(v -> {
            iniciar(intent);
        });
        btnParar.setOnClickListener(v -> {
            parar(intent);
        });
    }

    private void parar(Intent intent) {
        Toast.makeText(this, "Parando o serviço", Toast.LENGTH_SHORT).show();
        stopService(intent);
    }

    private void iniciar(Intent intent) {
        Toast.makeText(this, "Iniciando o serviço", Toast.LENGTH_SHORT).show();
        Log.i("Service1", Thread.currentThread().getName());
        startService(intent);
    }
}