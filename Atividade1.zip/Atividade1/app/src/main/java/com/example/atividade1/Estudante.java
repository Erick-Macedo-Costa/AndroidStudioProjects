package com.example.atividade1;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Estudante {

    @SerializedName("nome")
    @Expose
    private String nome;
    @SerializedName("ano_nascimento")
    @Expose
    private Integer anoNascimento;
    @SerializedName("notas")
    @Expose
    private Notas notas;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(Integer anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    public Notas getNotas() {
        return notas;
    }

    public void setNotas(Notas notas) {
        this.notas = notas;
    }
    public int verificarIdade(){
        int idade = 0;
        idade = 2023 - anoNascimento;
        return idade;
    }

    @Override
    public String toString() {
        return "Nome: " + nome+ "\n" + "Idade: " + verificarIdade() +  "\n" + notas + "\n";
    }

}