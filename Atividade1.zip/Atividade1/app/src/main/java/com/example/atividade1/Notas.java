package com.example.atividade1;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class Notas {

    @SerializedName("n1")
    @Expose
    private Integer n1;
    @SerializedName("n2")
    @Expose
    private Integer n2;
    @SerializedName("n3")
    @Expose
    private Integer n3;

    public Integer getN1() {
        return n1;
    }

    public void setN1(Integer n1) {
        this.n1 = n1;
    }

    public Integer getN2() {
        return n2;
    }

    public void setN2(Integer n2) {
        this.n2 = n2;
    }

    public Integer getN3() {
        return n3;
    }

    public void setN3(Integer n3) {
        this.n3 = n3;
    }
    public int verificarNotas(){
        int soma = n1 + n2 + n3;
        return soma /3;
    }
    public String situacao(){
        return (verificarNotas() >= 6) ? "Aprovado" : "Reprovado";
    }

    @Override
    public String toString() {
        return  "Media: " + verificarNotas() + "\n" + "Situação: " + situacao() + "\n" ;
    }

}