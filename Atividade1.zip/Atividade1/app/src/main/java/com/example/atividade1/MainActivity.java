package com.example.atividade1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private ListView listView;
    private final String URL= "https://my-json-server.typicode.com/Erick-Macedo-Costa/ExemplosPDM2/db";
    private StringBuilder builder = null;
    private Item dadosBaixados = null;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        new obterDados().execute();
    }//onCreate

    private class obterDados extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHttp(URL);
            Auxilia auxilia = new Auxilia();
            String textoJSON = auxilia.converter(inputStream);
            Log.i("JSON", "doInBackground: "+textoJSON);
            Gson gson = new Gson();
            builder = new StringBuilder();

            if(textoJSON != null){
                Type type = new TypeToken<Item>(){}.getType();
                dadosBaixados = gson.fromJson(textoJSON,type);
                for (int i = 0; i < dadosBaixados.getEstudantes().size(); i++){
                    builder.append(dadosBaixados.getEstudantes()).append(" ");;
                }//for
            }else{
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),"Não foi possível obter JSON", Toast.LENGTH_SHORT).show();
                    }
                });
            }//if else
            return null;

        }//doInBackground

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(getApplicationContext(),"Download começando...", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            //textView.setText(dadosBaixados.toString());

            if (dadosBaixados != null && dadosBaixados.getEstudantes() != null) {
                List<String> listaEstudantes = new ArrayList<>();

                for (Estudante estudante : dadosBaixados.getEstudantes()) {
                    listaEstudantes.add(estudante.toString());
                }

                listView = findViewById(R.id.listView);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, listaEstudantes);
                listView.setAdapter(adapter);
            } else {
                Toast.makeText(getApplicationContext(), "Não foi possível obter JSON", Toast.LENGTH_SHORT).show();
            }
        }

    }//inner class
}//class