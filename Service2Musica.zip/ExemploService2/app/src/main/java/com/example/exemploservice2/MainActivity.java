package com.example.exemploservice2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button btnIniciar, btnParar;
    private MediaPlayer mediaPlayer;
    private List<Integer> numerosGerados = new ArrayList<>();
    private EditText edtSoma;
    //private String numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer = MediaPlayer.create(this,R.raw.musica);
        btnIniciar = findViewById(R.id.botaoGO);
        btnParar = findViewById(R.id.botaoST);
        edtSoma = findViewById(R.id.editText);
        //numero = edtSoma.getText().toString();
        Intent intent = new Intent(this, MyService.class);
        btnIniciar.setOnClickListener(v -> {
            iniciar(intent);
            mediaPlayer.start();
            numeros();
            Toast.makeText(this, "Insira a somar", Toast.LENGTH_SHORT).show();
        });
        btnParar.setOnClickListener(v -> {
            parar(intent);
            mediaPlayer.stop();
            verificar();
        });
    }
    private void numeros() {
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            int numero = random.nextInt(15);
            numerosGerados.add(numero);
            Log.i("numeros", String.valueOf(numero));
            Toast.makeText(this, String.valueOf(numero), Toast.LENGTH_SHORT).show();
        }
    }

    private void parar(Intent intent) {
        Toast.makeText(this, "Parando o serviço", Toast.LENGTH_SHORT).show();
        stopService(intent);
    }

    private void iniciar(Intent intent) {
        Toast.makeText(this, "Iniciando o serviço", Toast.LENGTH_SHORT).show();
        Log.i("Service1", Thread.currentThread().getName());
        startService(intent);
    }

    private int calcularSoma() {
        int soma = 0;
        for (int numero : numerosGerados) {
            soma += numero;
        }
        return soma;
    }

    private void verificar() {
        //System.out.println(numero);
        int numero = Integer.parseInt(edtSoma.getText().toString());
        if (numero == calcularSoma()) {
            Toast.makeText(this, "Você acertou", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Você errou", Toast.LENGTH_SHORT).show();
        }
    }

}