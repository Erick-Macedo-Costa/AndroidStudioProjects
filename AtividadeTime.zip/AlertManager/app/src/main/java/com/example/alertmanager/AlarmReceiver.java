package com.example.alertmanager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CANAL_ID = "2";
    private static final int NOTIFICADO_ID = 1;
    private Notification builder;
    private NotificationManagerCompat manager;
    private static final String PERMISSAO = Manifest.permission.POST_NOTIFICATIONS;
    @SuppressLint("MissingPermission")
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent it = new Intent(context.getApplicationContext(), MainActivity2.class);
        it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context.getApplicationContext(),
                0, it, PendingIntent.FLAG_IMMUTABLE);
        criarCanalNotificacao(context);
        gerar(context);
        //context.startActivity(it);

    }
    private void gerar(Context context) {
        Intent i = new Intent(context, MainActivity2.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pi = PendingIntent.getActivity(context, 0,i,PendingIntent.FLAG_UPDATE_CURRENT);

        builder = new NotificationCompat.Builder(context,CANAL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Alerta")
                .setContentText("Alarme disparado")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pi)
                .build();

        manager = NotificationManagerCompat.from(context);
        int temPermissao = ContextCompat.checkSelfPermission(context, PERMISSAO);

        if(temPermissao == PackageManager.PERMISSION_GRANTED){
            manager.notify(NOTIFICADO_ID,builder);
        }

    }


    private void criarCanalNotificacao(Context context)
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence nome = "canal 1";
            String descricao = "descrição do canal 1";
            int importancia = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel canal = new NotificationChannel(CANAL_ID, nome, importancia);
            canal.setDescription(descricao);
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(canal);
        }
    }
}
