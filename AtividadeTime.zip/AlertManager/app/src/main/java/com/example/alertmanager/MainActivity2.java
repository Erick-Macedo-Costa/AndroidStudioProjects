package com.example.alertmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.example.alertmanager.json.Auxilia;
import com.example.alertmanager.json.Conexao;
import com.example.alertmanager.json.Matriz;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    private final String URL= "https://my-json-server.typicode.com/Erick-Macedo-Costa/ExemplosPDM2/db";
    private StringBuilder builder = null;
    private Matriz dadosBaixados = null;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView = findViewById(R.id.textView);
        new obterDados().execute();
    }
    private class obterDados extends AsyncTask<Void, Void, Void> { //AQUI LEIO O JSON

        @Override
        protected Void doInBackground(Void... voids) {
            Conexao conexao = new Conexao();
            InputStream inputStream = conexao.obterRespostaHTTP(URL);
            Auxilia auxilia = new Auxilia();
            String textoJSON = auxilia.converter(inputStream);
            //Log.i("JSON", "doInBackground: "+textoJSON);
            Gson gson = new Gson();
            builder = new StringBuilder();

            if(textoJSON != null){
                Type type = new TypeToken<Matriz>(){}.getType();
                dadosBaixados = gson.fromJson(textoJSON,type);
                for (int i = 0; i < dadosBaixados.getVetores().size(); i++) {
                    builder.append(dadosBaixados.getVetores().get(i).toString())
                            .append("\n");
                }
            }else{
                builder.append("Não foi possível obter os dados");
            }
            return null;
        }//doInBackground

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);
            textView.setText(builder.toString());
        }



    }//obterDados
}