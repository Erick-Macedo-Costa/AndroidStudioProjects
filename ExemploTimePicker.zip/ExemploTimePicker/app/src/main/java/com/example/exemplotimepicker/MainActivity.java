package com.example.exemplotimepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {

    private TimePicker timePicker;
    private Button botao;
    private TextView texto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timePicker = findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true);
        botao = findViewById(R.id.button);
        texto = findViewById(R.id.textView);
        botao.setOnClickListener(v -> obter());
    }
    private void obter(){
        int hora=0, minuto=0;
        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            hora = timePicker.getHour();
            minuto = timePicker.getMinute();
        }else{
            hora = timePicker.getCurrentHour();
            minuto = timePicker.getCurrentMinute();
        }
        String tempo = hora + ":" + minuto;
        texto.setText(tempo);
    }

}