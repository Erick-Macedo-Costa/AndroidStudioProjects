package com.example.exjasonlocal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText edtNome, edtDisciplina, edtNota;
    private Button btnAdicionar, btnGerar, btnConsumir;
    private List<Estudante> lista;
    private TextView txtResultado;
    private String retorno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.nome);
        edtDisciplina = findViewById(R.id.diciplina);
        edtNota = findViewById(R.id.nota);
        btnAdicionar = findViewById(R.id.adicionar);
        btnGerar = findViewById(R.id.gerar);
        btnConsumir = findViewById(R.id.consumir);
        lista = new ArrayList<>();
        txtResultado = findViewById(R.id.resultado);


    }//onCreate
    public void criarLista(View v){
        lista.add(new Estudante(edtNome.getText().toString(),
                edtDisciplina.getText().toString(),
                Integer.parseInt(edtNota.getText().toString())));
        Toast.makeText(this, "item inserido", Toast.LENGTH_SHORT).show();
    }//

//    public String criarJson(){
//        JSONArray jsonArray = new JSONArray();
//        for(int i=0;i<lista.size();i++){
//            JSONObject jsonObject = new JSONObject();
//            try {
//                jsonObject.put("nomeEstudante",lista.get(i).getNome());
//                jsonObject.put("disciplinaEstudante",lista.get(i).getDisciplina());
//                jsonObject.put("notaEstudante",lista.get(i).getNota());
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            jsonArray.put(jsonObject);
//        }//for
//        return "{estudantes:"+jsonArray.toString()+"}";
//    }// VERSAO ANTIGA - FUNCIONA - MAS NAO É A MELHOR

    public  String criarJson(List<Estudante> dados){
        Gson gson = new Gson();
        String json = gson.toJson(dados);
        return json;
    }

    public void gerarJson(View v){
        retorno = criarJson(lista);
        txtResultado.setText(retorno);
    }//

    public void abrirTela(View v){
        Intent it = new Intent(this, SegundaActivity.class);
        it.putExtra("dados",retorno);
        startActivity(it);
    }//
}//class