package com.example.exasynctaskatv;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Item {

    @SerializedName("agenda")
    @Expose
    private List<Agenda> agenda;
    @SerializedName("adicionais")
    @Expose
    private List<Adicionai> adicionais;

    public List<Agenda> getAgenda() {
        return agenda;
    }

    public void setAgenda(List<Agenda> agenda) {
        this.agenda = agenda;
    }

    public List<Adicionai> getAdicionais() {
        return adicionais;
    }

    public void setAdicionais(List<Adicionai> adicionais) {
        this.adicionais = adicionais;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Item.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("agenda");
        sb.append('=');
        sb.append(((this.agenda == null)?"<null>":this.agenda));
        sb.append(',');
        sb.append("adicionais");
        sb.append('=');
        sb.append(((this.adicionais == null)?"<null>":this.adicionais));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}